#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Only test file
"""


from glob import glob

annotation_path = "Annotations/*.xml" 
result_path = "ImageSets/Main/test.txt"

with open(result_path, 'a') as f:
    for file_name in glob(annotation_path):
        f.write(file_name[12:-4] + "\n")

