#!/bin/bash

# Copy test images to test_img_with_bb
# How to use: ./copy_test_images.sh < test.txt

while read line
do 
        filename=`echo "JPEGImages/$line.jpg"`
        cp $filename drawing/
done
                
