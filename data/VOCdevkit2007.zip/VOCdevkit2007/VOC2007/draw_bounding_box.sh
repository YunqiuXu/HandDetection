#!/bin/bash

bash copy_test_images.sh < ImageSets/Main/test.txt
python draw_box.py
